#!/usr/bin/env python
import cgi
import cgitb

cgitb.enable()

# 1/0 # Zero Division Error!

cgi.test()
